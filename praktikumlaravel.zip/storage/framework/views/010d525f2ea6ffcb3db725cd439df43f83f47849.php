<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Data Pegawai</title>

<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
integrity="sha384-
Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
crossorigin="anonymous">
</head>
<body>
<div class="container mt-4">
<center><h1 class="my-4">Halaman Data Pegawai</h1></center>
<div class="card mb-3">

<table class="table table-striped">
<thead>
<tr>

<th>Nama</th>
<th>Jabatan</th>
<th>Umur</th>
<th>Alamat</th>
</tr>
</thead>
<tbody>

<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>

<td><?php echo e($p->pegawai_nama); ?></td>
<td><?php echo e($p->pegawai_jabatan); ?></td>
<td><?php echo e($p->pegawai_umur); ?></td>
<td><?php echo e($p->pegawai_alamat); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>

Current Page: <?php echo e($pegawai->currentPage()); ?><br>
Jumlah Data: <?php echo e($pegawai->total()); ?><br>
Data perhalaman: <?php echo e($pegawai->perPage()); ?><br>
<br>
<?php echo e($pegawai->links()); ?>

</div>
</body>
</html>
<?php /**PATH C:\laragon\www\praktikumlaravel\resources\views/pegawai.blade.php ENDPATH**/ ?>